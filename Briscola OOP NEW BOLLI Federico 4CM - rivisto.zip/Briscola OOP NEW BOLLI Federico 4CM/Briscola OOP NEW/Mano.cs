﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Briscola_OOP_NEW
{
    public class Mano : PictureBox
    {
        public Carte carta;
        public Mano(Carte Aux, int X, int Y)
        {

            carta = Aux;
            BackColor = Color.Black;
            Location = new Point(X, Y);
            Size = new Size(90, 165);
            string carta1 = carta.valore.ToString() + carta.Genere.ToString() + ".png";
            Image = Image.FromFile(@"..\..\..\Carte\" + carta1);

        }
    }
}
