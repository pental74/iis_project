﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Briscola_OOP_NEW
{
    public partial class UserCPUGiocata : UserControl
    {
        public UserCPUGiocata()
        {
            InitializeComponent();
        }
    }
}
