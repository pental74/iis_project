﻿public enum seme//enum seme di 4 tipi come nella ver briscola
{
    bastoni,
    coppe,
    spade,
    denari
}