﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Briscola_OOP_NEW
{
    public partial class UserCPU : UserControl
    {
        public UserCPUGiocata userCPUgiocata { get;  set; }
        public UserCPU()
        {
            InitializeComponent();
        }

        public int punteggio;
        public Carte carta_giocata = null;
        public List<Mano> mano = new List<Mano>();
        public Mano carta_scelta;

        public void Pesca(Carte carta)
        {
            mano.Add(new Mano(carta, (mano.Count - 1) * 90 + 90, 2));
            this.Controls.Add(mano[mano.Count - 1]);
        }

        public void Gioca()
        {
            if (carta_giocata != null)
            {
                return;
            }
            int posizione = new Random().Next(0, mano.Count);
            carta_giocata = mano[posizione].carta;
            Mano carta_cancellare = new Mano(carta_giocata, posizione * 90 + 90, 2);

            // Carta_scelta instanzia una carta 
            carta_scelta = new Mano(carta_giocata, 1, 1);

            // Aggiunge la carta allo user Control Giocata al centro del tavolo
            this.userCPUgiocata.Visible = true;
            this.userCPUgiocata.Controls.Add(carta_scelta);

            // Rimuove la carta dalle 3 possedute dalla lista e dall'user Contro
            this.Controls.Remove(mano[posizione]);
            mano.Remove(mano[posizione]);

        }
    }
}
