﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Briscola_OOP_NEW
{
    public partial class UserUtente : UserControl
    {
        public UserUtenteGiocata userGiocata { get; set; }

        public UserUtente()
        {
            InitializeComponent();
        }

        public int punteggio;
        public Carte carta_giocata = null;
        public List<Mano> mano = new List<Mano>();
        public Mano carta_scelta;

        public void Pesca(Carte carta)
        {
            mano.Add(new Mano(carta, (mano.Count - 1) * 90+90, 2));
            mano[mano.Count - 1].Click += Gioca;
            this.Controls.Add(mano[mano.Count - 1]);
        }

        public void Gioca(object Sender, EventArgs e)
        {
            if (carta_giocata != null)
            {
                return;
            }

            // Prende seme e valore della carta scelta dall'utente
            carta_giocata = (Sender as Mano).carta;

            // Carta_scelta instanzia una carta 
            carta_scelta = new Mano((Sender as Mano).carta, 1, 1);
            // Aggiunge la carta allo user Control Giocata al centro del tavolo
            this.userGiocata.Visible = true;
            this.userGiocata.Controls.Add(carta_scelta);

            // Rimuove la carta dalle 3 possedute dalla lista e dall'user Control
            mano.Remove(Sender as Mano);
            this.Controls.Remove(Sender as Mano);
        }   
    }
}
