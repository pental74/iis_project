﻿
namespace Briscola_OOP_NEW
{
    partial class FormBriscola
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormBriscola));
            this.buttonGioca = new System.Windows.Forms.Button();
            this.buttonEsci = new System.Windows.Forms.Button();
            this.userUtente = new Briscola_OOP_NEW.UserUtente();
            this.userCpu = new Briscola_OOP_NEW.UserCPU();
            this.userUtenteGiocata = new Briscola_OOP_NEW.UserUtenteGiocata();
            this.userCPU_Giocata = new Briscola_OOP_NEW.UserCPUGiocata();
            this.SuspendLayout();
            // 
            // buttonGioca
            // 
            this.buttonGioca.Location = new System.Drawing.Point(636, 25);
            this.buttonGioca.Name = "buttonGioca";
            this.buttonGioca.Size = new System.Drawing.Size(128, 120);
            this.buttonGioca.TabIndex = 0;
            this.buttonGioca.Text = "NUOVA PARTITA";
            this.buttonGioca.UseVisualStyleBackColor = true;
            this.buttonGioca.Click += new System.EventHandler(this.buttonGioca_Click);
            // 
            // buttonEsci
            // 
            this.buttonEsci.Location = new System.Drawing.Point(636, 184);
            this.buttonEsci.Name = "buttonEsci";
            this.buttonEsci.Size = new System.Drawing.Size(128, 50);
            this.buttonEsci.TabIndex = 1;
            this.buttonEsci.Text = "ESCI";
            this.buttonEsci.UseVisualStyleBackColor = true;
            this.buttonEsci.Click += new System.EventHandler(this.buttonEsci_Click);
            // 
            // userUtente
            // 
            this.userUtente.BackColor = System.Drawing.Color.Transparent;
            this.userUtente.Location = new System.Drawing.Point(271, 385);
            this.userUtente.Name = "userUtente";
            this.userUtente.Size = new System.Drawing.Size(307, 166);
            this.userUtente.TabIndex = 3;
            this.userUtente.Visible = false;
            // 
            // userCpu
            // 
            this.userCpu.BackColor = System.Drawing.Color.Transparent;
            this.userCpu.Location = new System.Drawing.Point(263, 12);
            this.userCpu.Name = "userCpu";
            this.userCpu.Size = new System.Drawing.Size(322, 166);
            this.userCpu.TabIndex = 4;
            this.userCpu.Visible = false;
            // 
            // userUtente1
            // 
            this.userUtenteGiocata.BackColor = System.Drawing.Color.Transparent;
            this.userUtenteGiocata.Location = new System.Drawing.Point(312, 198);
            this.userUtenteGiocata.Name = "UserUtenteGiocata";
            this.userUtenteGiocata.Size = new System.Drawing.Size(91, 166);
            this.userUtenteGiocata.TabIndex = 5;
            this.userUtenteGiocata.Visible = false;
            // 
            // userUtente2
            // 
            this.userCPU_Giocata.BackColor = System.Drawing.Color.Transparent;
            this.userCPU_Giocata.Location = new System.Drawing.Point(441, 198);
            this.userCPU_Giocata.Name = "userCPUGiocata";
            this.userCPU_Giocata.Size = new System.Drawing.Size(91, 166);
            this.userCPU_Giocata.TabIndex = 6;
            this.userCPU_Giocata.Visible = false;
            // 
            // FormBriscola
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(800, 282);
            this.Controls.Add(this.userCPU_Giocata);
            this.Controls.Add(this.userUtenteGiocata);
            this.Controls.Add(this.userCpu);
            this.Controls.Add(this.userUtente);
            this.Controls.Add(this.buttonEsci);
            this.Controls.Add(this.buttonGioca);
            this.Name = "FormBriscola";
            this.Text = "Briscola";
            this.Load += new System.EventHandler(this.FormBriscola_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button buttonGioca;
        private System.Windows.Forms.Button buttonEsci;
        private UserUtente userUtente;
        private UserCPU userCpu;
        private UserUtenteGiocata userUtenteGiocata;
        private UserCPUGiocata userCPU_Giocata;
    }
}

