﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Threading;
namespace Briscola_OOP_NEW
{
    public partial class FormBriscola : Form
    {
        public FormBriscola()
        {
            InitializeComponent();
        }
        
        Mazzo mazzo = new Mazzo();

        private void buttonGioca_Click(object sender, EventArgs e)
        {
            if (File.Exists(@"..\..\..\Carte\sfondo.jpg")) 
            {
                Image sfondo = new Bitmap(@"..\..\..\Carte\sfondo.jpg");
                this.BackgroundImage = sfondo;
            }

            // Ridefinizione del Form principale Briscola
            this.Size = new Size(900, 600);
            buttonGioca.Visible = false;
            buttonEsci.Location = new Point(750, 500);
            
            // Operazioni preliminari prima dell'inizio della partita
            
            // Utente
            userUtente.userGiocata = userUtenteGiocata; // Proprietà Giocata (carta al centro del tavolo) dell'utente
            userUtenteGiocata.Visible = false;
            userUtente.Visible = true;

            // CPU
            userCpu.userCPUgiocata = userCPU_Giocata; // Proprietà Giocata (carta al centro del tavolo) del UserPC
            userCPU_Giocata.Visible = false;
            userCpu.Visible = true;
            
            mazzo.mescola();
            for(int i=0; i<3; i++)
            {
                userCpu.Pesca(mazzo.estrai());
                userUtente.Pesca(mazzo.estrai());
            }

            // Mano da giocare 20 complessive, 3 non devono pescare
            for (int mano_giocate = 1; mano_giocate <= 20; mano_giocate++)
            {
                userCpu.Gioca();
            }
        }
    
        
        private void buttonEsci_Click(object sender, EventArgs e)
        {
            Application.Exit();  
        }

        private void FormBriscola_Load(object sender, EventArgs e)
        {

        }

        /*public void Partita()
        {
            seme briscola = mazzo1.estraibriscola();
            bool prima_giocata = true;
            bool giocante = false;
            int[] punteggio = { 1000, 11, 0, 10, 0, 0, 0, 0, 2, 3, 4 };

            do
            {
                Mano cpu=null;
                Mano Utente=null;
                giocante = prima_giocata;
                Utente = new Mano(userUtente1.carta_giocata, 90, 180);

                for (int i = 0; i < 2; i++)
                {
                    if (giocante)
                    {
                        while (userUtente1.carta_giocata == null)
                        {

                        }
                        giocante = !giocante;
                        Utente = new Mano(userUtente1.carta_giocata, 90, 180);
                        this.Controls.Add(Utente);
                    }
                    else
                    {
                        usercpu1.Gioca();
                        cpu = new Mano(usercpu1.carta_giocata, 120, 180);
                        this.Controls.Add(cpu);
                        giocante = !giocante;
                    }


            }

        int pun_cpu = 0;
                int pun_utente = 0;

                if (usercpu1.carta_giocata.Genere != userUtente1.carta_giocata.Genere)
                {
                    if (usercpu1.carta_giocata.Genere == briscola)
                    {
                        pun_cpu = punteggio[userUtente1.carta_giocata.valore] + punteggio[usercpu1.carta_giocata.valore];
                    }
                    else if (userUtente1.carta_giocata.Genere == briscola)
                    {
                        pun_utente = punteggio[userUtente1.carta_giocata.valore] + punteggio[usercpu1.carta_giocata.valore];
                    }
                    else if (prima_giocata)
                    {
                        pun_utente = punteggio[userUtente1.carta_giocata.valore] + punteggio[usercpu1.carta_giocata.valore];
                    }
                    else
                    {
                        pun_cpu = punteggio[userUtente1.carta_giocata.valore] + punteggio[usercpu1.carta_giocata.valore];
                    }
                }
                else
                {
                    if (punteggio[userUtente1.carta_giocata.valore] > punteggio[usercpu1.carta_giocata.valore])
                    {
                        pun_utente = punteggio[userUtente1.carta_giocata.valore] + punteggio[usercpu1.carta_giocata.valore];
                    }
                    else
                    {
                        pun_cpu = punteggio[userUtente1.carta_giocata.valore] + punteggio[usercpu1.carta_giocata.valore];
                    }
                }

                userUtente1.punteggio += pun_utente;
                usercpu1.punteggio += pun_cpu;

                Thread.Sleep(3000);
                if (mazzo1.mazzo.Count == 0)
                {
                    continue;
                }
                if (pun_utente > pun_cpu)
                {
                    prima_giocata = true;
                    userUtente1.Pesca(mazzo1.estrai());
                    usercpu1.Pesca(mazzo1.estrai());
                }
                else
                {
                    prima_giocata = false;
                    usercpu1.Pesca(mazzo1.estrai());
                    userUtente1.Pesca(mazzo1.estrai());

                }
                this.Controls.Remove(Utente);
                this.Controls.Remove(cpu);
            } while (userUtente1.mano1.Count != 0 && usercpu1.mano1.Count != 0);

            
        }
        */
    }
}
